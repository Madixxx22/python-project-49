#!/usr/bin/env python3
from brain_games.games.greetings import greetings


def main():
    greetings()


if __name__ == "__main__":
    main()
