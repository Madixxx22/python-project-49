import prompt


def welcome_user() -> str:
    return prompt.string('May I have your name? ')
