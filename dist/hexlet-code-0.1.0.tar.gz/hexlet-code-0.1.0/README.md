### Hexlet tests and linter status:
[![Actions Status](https://github.com/Madixxx22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Madixxx22/python-project-49/actions)
<a href="https://codeclimate.com/github/Madixxx22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/36af7edc4f02d1c8dc8a/maintainability" /></a>

Аскинема: https://asciinema.org/a/8AVcUHdOSv6Hbuvh1y05oh4EM